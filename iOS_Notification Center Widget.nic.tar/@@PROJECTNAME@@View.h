//
//  @@PROJECTNAME@@View.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface @@PROJECTNAME@@View : UIView

- (void)setBackgroundImage:(UIImage *)backgroundImage;

- (void)loadFullView;

@end