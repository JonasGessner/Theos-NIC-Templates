//
//  @@PROJECTNAME@@ViewControllerNew.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import "SpringBoardUIServices/_SBUIWidgetViewController.h"

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface @@PROJECTNAME@@ViewControllerNew : _SBUIWidgetViewController

@end