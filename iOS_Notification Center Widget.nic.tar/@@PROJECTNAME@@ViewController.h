//
//  @@PROJECTNAME@@ViewController.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#ifndef __LP64__


#import "BBWeeAppController-Protocol.h"

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface @@PROJECTNAME@@ViewController : NSObject <BBWeeAppController>

@end


#endif