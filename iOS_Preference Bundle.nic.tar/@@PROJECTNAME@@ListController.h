//
//  @@PROJECTNAME@@ListController.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import "Preferences/PSListController.h"

@interface @@PROJECTNAME@@ListController : PSListController

@end
