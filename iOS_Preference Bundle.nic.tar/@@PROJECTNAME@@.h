//
//  @@PROJECTNAME@@.hh
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Preferences/Preferences.h>

@interface @@PROJECTNAME@@ListController : PSListController

@end
