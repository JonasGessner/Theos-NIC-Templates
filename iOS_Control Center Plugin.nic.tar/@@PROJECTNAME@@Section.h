//
//  @@PROJECTNAME@@Section.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import "CCSection-Protocol.h"
#import "@@PROJECTNAME@@SectionView.h"

@interface @@PROJECTNAME@@Section : NSObject <CCSection>

@end
