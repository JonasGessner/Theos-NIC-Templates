//
//  main.m
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, char **argv, char **envp) {
    @autoreleasepool {
        //Do whatever you have to do
    }
    
    return 0;
}
